﻿using Common.Views;
using Okta.Xamarin;
using System;
using Xamarin.Forms;

namespace $safeprojectname$.Views
{
    public partial class AboutPage : ContentPage
    {
        public AboutPage()
        {
            InitializeComponent();
        }
    }
}